<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;
use Symfony\Component\DomCrawler\Crawler;

$atomy_url = 'https://www.atomy.com/';
$mall_main_url = 'https://www.atomy.com/in/Home/Product/MallMain';
$remote_json_url = 'https://saikiasan.github.io/atomy-product-details/buyer-data.json';
$phone_number = '+918822494773';

function fetchAllProducts($url, $atomy_url)
{
  $client = new Client([
    'headers' => [
      'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
    ],
    'verify' => false
  ]);

  try {
    $response = $client->get($url);
    $html = $response->getBody()->getContents();

    $formData = [
      'LargeClass' => '00',
      'MiddleClass' => '00',
      'SmallClass' => '00',
      'MatLevel' => '0',
      'Order' => 'basic',
      'CurrentPageNo' => '1',
      'ListType' => '',
      'CountPerPage' => '1000'
    ];

    $response = $client->post($url, [
      'form_params' => $formData,
      'headers' => [
        'Referer' => $url,
        'Origin' => $atomy_url
      ]
    ]);

    return $response->getBody()->getContents();
  } catch (Exception $e) {
    echo "Error fetching products: " . $e->getMessage() . "\n";
    return null;
  }
}

function extractProducts($html, $atomy_url)
{
  $crawler = new Crawler($html);
  $products = [];

  $crawler->filter('ul.pBox')->each(function (Crawler $pBox) use (&$products, $atomy_url) {
    try {
      $product = [
        'imageUrl' => '',
        'title' => '',
        'price' => 0,
        'gds' => ''
      ];

      try {
        $img = $pBox->filter('li.pimg img')->first();
        $product['imageUrl'] = $atomy_url . ltrim($img->attr('src'), '/');
      } catch (Exception $e) {
      }

      try {
        $title = $pBox->filter('li.ptitle a')->first();
        $product['title'] = trim($title->text());
        $href = $title->attr('href');
        if (preg_match('/GdsCode=([^&]+)/', $href, $matches)) {
          $product['gds'] = $matches[1];
        }
      } catch (Exception $e) {
      }

      try {
        $price = $pBox->filter('li.pprice .numberic')->first();
        $product['price'] = (float) preg_replace('/[^0-9.]/', '', $price->text());
      } catch (Exception $e) {
      }

      if (!empty($product['title'])) {
        $products[] = $product;
      }
    } catch (Exception $e) {
    }
  });

  return $products;
}

function compareWithRemoteJson($local_products, $remote_url)
{
  try {
    $client = new Client(['verify' => false]);
    $response = $client->get($remote_url);
    $remote_json = $response->getBody()->getContents();
    $remote_products = json_decode($remote_json, true);

    if (json_encode($local_products) !== json_encode($remote_products)) {
      return [
        'changed' => true,
        'changes' => [
          'added' => array_udiff($local_products, $remote_products, fn($a, $b) => $a['gds'] <=> $b['gds']),
          'removed' => array_udiff($remote_products, $local_products, fn($a, $b) => $a['gds'] <=> $b['gds']),
          'modified' => array_uintersect($local_products, $remote_products, fn($a, $b) =>
            $a['gds'] === $b['gds'] && json_encode($a) !== json_encode($b) ? 0 : -1)
        ]
      ];
    }
    return ['changed' => false];
  } catch (Exception $e) {
    echo "Error comparing with remote JSON: " . $e->getMessage() . "\n";
    return ['changed' => false];
  }
}

function sendSMSNotification($phone, $message)
{
  // Clean the phone number
  $clean_phone = preg_replace('/[^0-9]/', '', $phone);

  // Carrier detection (for Indian numbers)
  $prefix = substr($clean_phone, 0, 2);
  $carriers = [
    '70' => 'jio',      // Jio numbers often start with 70
    '80' => 'jio',      // and other ranges
    '90' => 'jio',
    '91' => 'airtel',   // Default to Airtel if we can't determine
    '81' => 'vodafone',
    '82' => 'idea',
    '85' => 'jio'
  ];

  $carrier = $carriers[$prefix] ?? 'airtel'; // Default to Airtel if unknown

  $carrier_gateways = [
    'airtel' => '@airtelkk.com',
    'vodafone' => '@vodafone-sms.com',
    'idea' => '@ideacellular.net',
    'jio' => '@sms.jio.com'
  ];

  // For Jio numbers (remove country code and any leading zeros)
  $local_number = preg_replace('/^\+?91|^0/', '', $clean_phone);
  $email = $local_number . $carrier_gateways[$carrier];

  try {
    // Send email
    $subject = 'Atomy Update';
    $headers = 'From: your-email@yourdomain.com' . "\r\n";

    if (mail($email, $subject, $message, $headers)) {
      echo "SMS notification sent via $carrier gateway to $phone\n";
      return true;
    } else {
      echo "Failed to send SMS via $carrier gateway\n";
      return false;
    }
  } catch (Exception $e) {
    echo "Email-to-SMS failed: " . $e->getMessage() . "\n";
    return false;
  }
}

// Main execution
try {
    echo "Fetching products from Atomy...\n";
    $html = fetchAllProducts($mall_main_url, $atomy_url);

    if ($html) {
        $products = extractProducts($html, $atomy_url);

        if (!empty($products)) {
            $output_file = 'p.json';
            // CORRECTED: Changed $data to $products
            file_put_contents($output_file, json_encode($products, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
            echo "Saved " . count($products) . " products to $output_file\n";

            // Compare with remote JSON
            $comparison = compareWithRemoteJson($products, $remote_json_url);

            if ($comparison['changed']) {
                $changes_count = count($comparison['changes']['added']) +
                               count($comparison['changes']['removed']) +
                               count($comparison['changes']['modified']);

                $message = "Atomy products changed! Changes detected: " . $changes_count . 
                          ". Added: " . count($comparison['changes']['added']) . 
                          ", Removed: " . count($comparison['changes']['removed']) . 
                          ", Modified: " . count($comparison['changes']['modified']);

                echo $message . "\n";
                sendSMSNotification($phone_number, $message);

                // Save changes to a separate file
                file_put_contents('changes.json', json_encode($comparison['changes'], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
                
                // Additional debug info
                file_put_contents('changes-details.txt', 
                    "=== Added Products ===\n" . print_r($comparison['changes']['added'], true) .
                    "\n=== Removed Products ===\n" . print_r($comparison['changes']['removed'], true) .
                    "\n=== Modified Products ===\n" . print_r($comparison['changes']['modified'], true)
                );
            } else {
                echo "No changes detected compared to remote JSON.\n";
                // Log this check for history
                file_put_contents('scan-log.txt', date('Y-m-d H:i:s') . ": No changes detected\n", FILE_APPEND);
            }
        } else {
            echo "No products extracted. Check debug.html\n";
            file_put_contents('debug.html', $html);
            // Send alert about extraction failure
            sendSMSNotification($phone_number, "Atomy Scraper Failed: No products extracted");
        }
    }
} catch (Exception $e) {
    $error_msg = "Error: " . $e->getMessage() . "\n";
    echo $error_msg;
    // Send error alert via SMS
    sendSMSNotification($phone_number, "Atomy Scraper Error: " . substr($e->getMessage(), 0, 120));
    // Log full error
    file_put_contents('error-log.txt', date('Y-m-d H:i:s') . ": " . $error_msg, FILE_APPEND);
}
?>