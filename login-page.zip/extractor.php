<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;
use Symfony\Component\DomCrawler\Crawler;

$atomy_url = 'https://www.atomy.com/';
$mall_main_url = 'https://www.atomy.com/in/Home/Product/MallMain';

function fetchAllProducts($url, $atomy_url)
{
  $client = new Client([
    'headers' => [
      'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
      'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
      'Content-Type' => 'application/x-www-form-urlencoded'
    ],
    'cookies' => true,
    'verify' => false
  ]);

  try {
    // First request to get the page
    $response = $client->get($url);
    $html = $response->getBody()->getContents();

    // Prepare form data to show all products
    $formData = [
      'LargeClass' => '00',
      'MiddleClass' => '00',
      'SmallClass' => '00',
      'MatLevel' => '0',
      'Order' => 'basic',
      'CurrentPageNo' => '1',
      'ListType' => '',
      'CountPerPage' => '1000' // "View all" option
    ];

    // Submit the form with modified values
    $response = $client->post($url, [
      'form_params' => $formData,
      'headers' => [
        'Referer' => $url,
        'Origin' => $atomy_url
      ]
    ]);

    return $response->getBody()->getContents();
  } catch (Exception $e) {
    echo "Error fetching all products: " . $e->getMessage() . "\n";
    return null;
  }
}

function extractProducts($html, $atomy_url)
{
  $crawler = new Crawler($html);
  $products = [];

  $crawler->filter('ul.pBox')->each(function (Crawler $pBox) use (&$products, $atomy_url) {
    try {
      $product = [
        'imageUrl' => '',
        'title' => '',
        'price' => 0,
        'gds' => ''
      ];

      // Image URL
      try {
        $img = $pBox->filter('li.pimg img')->first();
        $product['imageUrl'] = $atomy_url . ltrim($img->attr('src'), '/');
      } catch (Exception $e) {
        echo "Image not found for a product\n";
      }

      // Title and Product URL
      try {
        $title = $pBox->filter('li.ptitle a')->first();
        $product['title'] = trim($title->text());

        // Fix product URL format
        $href = $title->attr('href');
        // if (strpos($href, './ProductView') === 0) {
        //   $product['productUrl'] = $atomy_url . 'in/Home/Product/' . substr($href, 2);
        // } else {
        //   $product['productUrl'] = $atomy_url . ltrim($href, '/');
        // }

        // Extract GDS code
        if (preg_match('/GdsCode=([^&]+)/', $href, $matches)) {
          $product['gds'] = $matches[1];
        }
      } catch (Exception $e) {
        echo "Title not found for a product\n";
      }

      // Price
      try {
        $price = $pBox->filter('li.pprice .numberic')->first();
        $product['price'] = (float) preg_replace('/[^0-9.]/', '', $price->text());
      } catch (Exception $e) {
        echo "Price not found for a product\n";
      }

      if (!empty($product['title'])) {
        $products[] = $product;
      }
    } catch (Exception $e) {
      echo "Error processing a product: " . $e->getMessage() . "\n";
    }
  });

  return $products;
}

function saveProductsToJson($products, $filename = 'p.json')
{
  $jsonData = json_encode($products, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
  file_put_contents($filename, $jsonData);
  echo "Successfully saved " . count($products) . " products to $filename\n";
}

// Main execution
try {
  global $atomy_url, $mall_main_url;

  echo "Fetching ALL products from Atomy...\n";
  $html = fetchAllProducts($mall_main_url, $atomy_url);

  if ($html) {
    $products = extractProducts($html, $atomy_url);
    if (!empty($products)) {
      saveProductsToJson($products);
    } else {
      echo "No products were extracted. The website structure may have changed.\n";
      file_put_contents('debug.html', $html);
      echo "Debug HTML saved to debug.html\n";
    }
  }
} catch (Exception $e) {
  echo "An error occurred: " . $e->getMessage() . "\n";
}
?>